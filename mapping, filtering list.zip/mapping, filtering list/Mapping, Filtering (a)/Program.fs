﻿let bidhan = [75000; 48000; 120000; 190000; 300113; 92000; 36000]

let printHighIncomeSalaries (salaries: int list) =
    salaries
    |> List.filter (fun salary -> salary > 100000)
    |> List.iteri (fun i salary -> printfn "Employee with high income %d: $%d" (i + 1) salary)

printHighIncomeSalaries bidhan
