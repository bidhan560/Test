﻿let bidhan = [75000; 48000; 120000; 190000; 300113; 92000; 36000]

let x y =
    y
    |> List.filter (fun z -> z > 100000) 
    |> List.iteri (fun i z -> printfn "Employee with high income %d: $%d" (i + 1) z)


x bidhan
