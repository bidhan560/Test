﻿let bidhan = [75000; 48000; 120000; 190000; 300113; 92000; 36000]

let incrementSalary salary = salary + 20000

let updatedSalaries = 
    bidhan 
    |> List.filter (fun salary -> salary < 49020)
    |> List.map (fun salary -> (salary, incrementSalary salary))

updatedSalaries |> List.iter (fun (original, updated) ->
    printfn "Original salary: $%d, Updated salary: $%d" original updated)
