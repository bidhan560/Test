﻿let bidhan = [75000; 48000; 120000; 190000; 300113; 92000; 36000]

let y x = x + 20000

let z = 
    bidhan 
    |> List.filter (fun x -> x < 49020)
    |> List.map (fun x -> (x, y x))

z |> List.iter (fun (original, updated) ->
    printfn "Original salary: $%d, Updated salary: $%d" original updated)
