﻿let bidhan = [75000; 48000; 120000; 190000; 300113; 92000; 36000]

let calculateTax salary =
    let salaryAsFloat = float salary
    match salary with
    | _ when salary <= 49020 -> salaryAsFloat * 0.15
    | _ when salary <= 98040 -> salaryAsFloat * 0.205
    | _ when salary <= 151978 -> salaryAsFloat * 0.26
    | _ when salary <= 216511 -> salaryAsFloat * 0.29
    | _ -> salaryAsFloat * 0.33

let taxes = bidhan |> List.map calculateTax

taxes |> List.iteri (fun i tax -> printfn "Employee %d: $%f" (i + 1) tax)
