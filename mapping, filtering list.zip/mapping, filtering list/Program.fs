﻿let bidhan = [75000; 48000; 120000; 190000; 300113; 92000; 36000]

let printSalaries (salaries: int list) =
    salaries
    |> List.iteri (fun i salary -> printfn "Employee %d: $%d" (i + 1) salary)

printSalaries bidhan
