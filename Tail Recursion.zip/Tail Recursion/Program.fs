﻿let bidhan max =

    let rec x y z =
        if y <= 0 then z
        else x (y - 3) (z + y) 
    x max 0 

let result = bidhan 18
printfn "The sum of multiples of 3 up to 18 :  %d" result
