﻿let sumMultiplesOfThree max =

    let rec sumHelper n acc =
        if n <= 0 then acc
        else sumHelper (n - 3) (acc + n) 
    sumHelper max 0 

let result = sumMultiplesOfThree 18
printfn "The sum of multiples of 3 up to 18 :  %d" result
